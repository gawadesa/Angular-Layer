export interface Product {
    id: number;
    Product_Name: string;
    price: number;
}